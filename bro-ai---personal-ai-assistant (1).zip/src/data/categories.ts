import { CategoryInfo, CategoryMode } from '../types';

export const CATEGORIES: Record<CategoryMode, CategoryInfo> = {
  all: {
    id: 'all',
    name: 'All-Rounder BRO',
    iconName: 'Sparkles',
    description: 'Your versatile, futuristic companion for any question, task, or brainstorm.',
    color: 'from-cyan-500 to-blue-600',
    prompts: [
      {
        title: 'Quick Summary',
        prompt: 'Break down quantum computing in simple terms that anyone can understand.',
      },
      {
        title: 'Brainstorm Ideas',
        prompt: 'Give me 5 creative science fair project ideas that stand out.',
      },
      {
        title: 'Friendly Advice',
        prompt: 'How can I stay disciplined and consistent when building a new habit?',
      },
      {
        title: 'Explore Tech',
        prompt: 'What are the most promising breakthroughs in renewable energy this decade?',
      },
    ],
  },
  math: {
    id: 'math',
    name: 'Math & STEM Solver',
    iconName: 'Calculator',
    description: 'Step-by-step solutions, equations, calculus, algebra, and physics proofs.',
    color: 'from-emerald-400 to-teal-600',
    prompts: [
      {
        title: 'Solve Quadratic',
        prompt: 'Solve step-by-step: 2x² + 7x - 15 = 0 using both factoring and the quadratic formula.',
      },
      {
        title: 'Derivatives & Calculus',
        prompt: 'Find the derivative of f(x) = (3x² + 2) / (x - 1) step-by-step using quotient rule.',
      },
      {
        title: 'Physics Concept',
        prompt: 'Explain Bernoulli’s Principle with real-world examples like airplane wings and baseball pitches.',
      },
      {
        title: 'Geometry & Trig',
        prompt: 'How do you find the area of an oblique triangle when given two sides and the included angle?',
      },
    ],
  },
  study: {
    id: 'study',
    name: 'Schoolwork & Study Buddy',
    iconName: 'GraduationCap',
    description: 'Essay outlines, concept breakdowns, test revision, and literature analysis.',
    color: 'from-blue-400 to-indigo-600',
    prompts: [
      {
        title: 'Essay Structure',
        prompt: 'Help me outline a persuasive 5-paragraph essay on why space exploration is worth the investment.',
      },
      {
        title: 'Biology Concept',
        prompt: 'Explain the light-dependent and Calvin cycle stages of photosynthesis simply.',
      },
      {
        title: 'History Breakdown',
        prompt: 'What were the primary economic and political causes of the Industrial Revolution?',
      },
      {
        title: 'Active Recall Quiz',
        prompt: 'Create 5 challenging multiple choice quiz questions about cell biology to test my knowledge.',
      },
    ],
  },
  research: {
    id: 'research',
    name: 'Research & Deep Dive',
    iconName: 'Compass',
    description: 'In-depth factual overviews, balanced perspectives, comparisons, and citations.',
    color: 'from-purple-400 to-pink-600',
    prompts: [
      {
        title: 'Fusion vs Fission',
        prompt: 'Compare nuclear fusion vs nuclear fission: mechanisms, energy yield, safety, and current feasibility.',
      },
      {
        title: 'Neuroscience Insight',
        prompt: 'How does neuroplasticity work in the adult human brain when learning complex skills?',
      },
      {
        title: 'Global Economy',
        prompt: 'Explain how central banks use interest rates to combat inflation and its effects on consumers.',
      },
      {
        title: 'AI Architecture',
        prompt: 'Provide a structured comparison between Transformer attention mechanisms and State Space Models (SSMs).',
      },
    ],
  },
  code: {
    id: 'code',
    name: 'Coding & Debugging',
    iconName: 'Code',
    description: 'Clean code generation, bug fixing, algorithm explanations, and architecture.',
    color: 'from-amber-400 to-orange-600',
    prompts: [
      {
        title: 'Python Web Scraper',
        prompt: 'Write a clean, robust Python script using BeautifulSoup to safely fetch article headlines.',
      },
      {
        title: 'Async/Await in JS',
        prompt: 'Explain how Promises and async/await work under the hood in the JavaScript Event Loop.',
      },
      {
        title: 'REST API Design',
        prompt: 'Design a clean RESTful API schema for a personal task manager with authentication.',
      },
      {
        title: 'Algorithm Primer',
        prompt: 'Explain the Binary Search algorithm with time complexity analysis and a TypeScript implementation.',
      },
    ],
  },
  tasks: {
    id: 'tasks',
    name: 'Everyday Productivity',
    iconName: 'CheckCircle2',
    description: 'Daily schedules, polite correspondence, workout planning, and life hacks.',
    color: 'from-cyan-400 to-emerald-500',
    prompts: [
      {
        title: 'High-Impact Morning',
        prompt: 'Design a realistic 45-minute morning routine that boosts mental focus and energy for studying.',
      },
      {
        title: 'Polite Professional Email',
        prompt: 'Draft a polite, professional email asking my professor or teacher for a 48-hour assignment extension.',
      },
      {
        title: 'Weekly Meal Prep',
        prompt: 'Give me a healthy, budget-friendly 5-day meal prep plan for a student with minimal cooking time.',
      },
      {
        title: 'Time Blocking Plan',
        prompt: 'How can I organize a 4-hour study session using the Pomodoro technique for maximum retention?',
      },
    ],
  },
};
