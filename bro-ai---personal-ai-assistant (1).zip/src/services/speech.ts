// Speech recognition and synthesis service

export interface SpeechRecognitionHandlers {
  onStart?: () => void;
  onResult?: (transcript: string, isFinal: boolean) => void;
  onError?: (errorMessage: string) => void;
  onEnd?: () => void;
}

export class SpeechService {
  private static recognitionInstance: any = null;
  private static isListening: boolean = false;

  // Check if browser supports speech recognition
  public static isRecognitionSupported(): boolean {
    return typeof window !== 'undefined' && 
      Boolean((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);
  }

  // Start listening to microphone
  public static startListening(handlers: SpeechRecognitionHandlers, lang: string = 'en-US'): boolean {
    if (!this.isRecognitionSupported()) {
      handlers.onError?.('Speech recognition is not supported in this browser. Please use Google Chrome or Android Chrome.');
      return false;
    }

    try {
      this.stopListening();

      const SpeechRecognitionClass = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const recognition = new SpeechRecognitionClass();

      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = lang;
      recognition.maxAlternatives = 1;

      recognition.onstart = () => {
        this.isListening = true;
        handlers.onStart?.();
      };

      recognition.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const transcriptChunk = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += transcriptChunk;
          } else {
            interimTranscript += transcriptChunk;
          }
        }

        const text = finalTranscript || interimTranscript;
        const isFinal = Boolean(finalTranscript);
        handlers.onResult?.(text, isFinal);
      };

      recognition.onerror = (event: any) => {
        this.isListening = false;
        let message = 'Microphone error occurred.';
        if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
          message = 'Microphone permission was denied. Please allow microphone access in your browser settings.';
        } else if (event.error === 'no-speech') {
          message = 'No speech detected. Please speak clearly into your microphone.';
        } else if (event.error === 'network') {
          message = 'Network error while attempting speech recognition.';
        }
        handlers.onError?.(message);
      };

      recognition.onend = () => {
        this.isListening = false;
        handlers.onEnd?.();
      };

      recognition.start();
      this.recognitionInstance = recognition;
      return true;
    } catch (err: any) {
      this.isListening = false;
      handlers.onError?.(err?.message || 'Could not start microphone.');
      return false;
    }
  }

  public static stopListening(): void {
    if (this.recognitionInstance) {
      try {
        this.recognitionInstance.stop();
      } catch {
        // ignore already stopped
      }
      this.recognitionInstance = null;
    }
    this.isListening = false;
  }

  public static getIsListening(): boolean {
    return this.isListening;
  }

  // --- Text-to-Speech (TTS) ---

  public static isSynthesisSupported(): boolean {
    return typeof window !== 'undefined' && 'speechSynthesis' in window;
  }

  public static getVoices(): Promise<SpeechSynthesisVoice[]> {
    return new Promise((resolve) => {
      if (!this.isSynthesisSupported()) {
        resolve([]);
        return;
      }

      let voices = window.speechSynthesis.getVoices();
      if (voices.length > 0) {
        resolve(voices);
        return;
      }

      // In Chrome/Android voices load asynchronously
      const onVoicesChanged = () => {
        voices = window.speechSynthesis.getVoices();
        window.speechSynthesis.onvoiceschanged = null;
        resolve(voices);
      };
      window.speechSynthesis.onvoiceschanged = onVoicesChanged;

      // Fallback timeout
      setTimeout(() => {
        resolve(window.speechSynthesis.getVoices());
      }, 500);
    });
  }

  // Clean markdown and symbols for natural conversational speaking
  public static cleanTextForSpeech(text: string): string {
    let clean = text;
    // Remove code blocks
    clean = clean.replace(/```[\s\S]*?```/g, 'Code block omitted.');
    // Remove inline code
    clean = clean.replace(/`([^`]+)`/g, '$1');
    // Remove markdown links [title](url) -> title
    clean = clean.replace(/\[([^\]]+)\]\([^)]+\)/g, '$1');
    // Remove headers (# Header)
    clean = clean.replace(/^#+\s+/gm, '');
    // Remove asterisks and underscores
    clean = clean.replace(/[*_~`]/g, '');
    // Clean bullet points
    clean = clean.replace(/^\s*[-*+]\s+/gm, '');
    // Remove LaTeX math delimiters
    clean = clean.replace(/\$\$[\s\S]*?\$\$/g, 'mathematical expression');
    clean = clean.replace(/\$([^$]+)\$/g, '$1');
    // Normalize spaces and line breaks
    clean = clean.replace(/\n+/g, '. ');
    clean = clean.replace(/\s+/g, ' ').trim();
    return clean;
  }

  // Speak text with custom settings
  public static speak(
    text: string,
    options: {
      voiceURI?: string;
      rate?: number;
      pitch?: number;
      volume?: number;
      onStart?: () => void;
      onEnd?: () => void;
      onError?: (err: any) => void;
    } = {}
  ): boolean {
    if (!this.isSynthesisSupported()) {
      options.onError?.('Speech synthesis not supported in this browser.');
      return false;
    }

    try {
      window.speechSynthesis.cancel(); // Stop any currently speaking audio

      const cleanText = this.cleanTextForSpeech(text);
      if (!cleanText) return false;

      const utterance = new SpeechSynthesisUtterance(cleanText);
      utterance.rate = options.rate ?? 1.0;
      utterance.pitch = options.pitch ?? 1.0;
      utterance.volume = options.volume ?? 1.0;

      const voices = window.speechSynthesis.getVoices();
      if (options.voiceURI) {
        const found = voices.find((v) => v.voiceURI === options.voiceURI);
        if (found) {
          utterance.voice = found;
        }
      } else {
        // Preferred natural English voices
        const naturalVoice = voices.find(
          (v) =>
            v.lang.startsWith('en') &&
            (v.name.includes('Natural') ||
              v.name.includes('Google') ||
              v.name.includes('Samantha') ||
              v.name.includes('Daniel') ||
              v.name.includes('Alex'))
        );
        if (naturalVoice) {
          utterance.voice = naturalVoice;
        }
      }

      utterance.onstart = () => {
        options.onStart?.();
      };

      utterance.onend = () => {
        options.onEnd?.();
      };

      utterance.onerror = (e) => {
        // "canceled" or "interrupted" is common when stopping
        if (e.error !== 'canceled' && e.error !== 'interrupted') {
          options.onError?.(e);
        }
        options.onEnd?.();
      };

      window.speechSynthesis.speak(utterance);
      return true;
    } catch (e) {
      options.onError?.(e);
      return false;
    }
  }

  public static stopSpeaking(): void {
    if (this.isSynthesisSupported()) {
      window.speechSynthesis.cancel();
    }
  }

  public static isSpeaking(): boolean {
    if (!this.isSynthesisSupported()) return false;
    return window.speechSynthesis.speaking;
  }
}
