import React, { useState, useEffect, useRef } from 'react';
import {
  Menu,
  Plus,
  Send,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Sliders,
  Sparkles,
  AlertCircle,
  Square,
  RefreshCw,
  Share2,
  User,
  ArrowDown,
  Layers,
} from 'lucide-react';
import { Conversation, Message, CategoryMode, VoiceSettings } from './types';
import { CATEGORIES } from './data/categories';
import { SpeechService } from './services/speech';
import { BROOrb } from './components/BROOrb';
import { MarkdownMessage } from './components/MarkdownMessage';
import { Sidebar } from './components/Sidebar';
import { VoiceModal } from './components/VoiceModal';
import { QuickPrompts } from './components/QuickPrompts';

const STORAGE_KEY = 'bro_ai_conversations_v1';
const SETTINGS_KEY = 'bro_ai_voice_settings_v1';

const DEFAULT_WELCOME_MESSAGE: Message = {
  id: 'welcome-msg',
  role: 'assistant',
  content: `Hey there! I'm **BRO AI**, your personal futuristic assistant. 🚀\n\nI'm here to help you conquer anything on your plate:\n- 📐 **Mathematics & STEM**: Step-by-step calculus, algebra, and physics calculations.\n- 📚 **Schoolwork & Study**: Essay drafting, concept breakdowns, test prep, and homework.\n- 🔬 **Research & Deep Dives**: Factual analyses, pros/cons, and literature summaries.\n- 💻 **Coding & Tech**: Debugging, algorithms, and clean script building.\n- ⚡ **Everyday Productivity**: Daily planning, polite emails, and life organization.\n\nYou can type your question below or tap the **microphone icon** to speak directly to me! How can I help you today?`,
  timestamp: Date.now(),
  status: 'complete',
};

const DEFAULT_CONVERSATION: Conversation = {
  id: 'conv-default',
  title: 'Welcome to BRO AI',
  messages: [DEFAULT_WELCOME_MESSAGE],
  createdAt: Date.now(),
  updatedAt: Date.now(),
  category: 'all',
};

const DEFAULT_SETTINGS: VoiceSettings = {
  autoSpeak: false,
  voiceURI: '',
  rate: 1.0,
  pitch: 1.0,
  volume: 1.0,
};

export default function App() {
  // State
  const [conversations, setConversations] = useState<Conversation[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error('Failed to load conversations:', e);
    }
    return [DEFAULT_CONVERSATION];
  });

  const [activeId, setActiveId] = useState<string>(() => {
    return conversations[0]?.id || DEFAULT_CONVERSATION.id;
  });

  const [voiceSettings, setVoiceSettings] = useState<VoiceSettings>(() => {
    try {
      const saved = localStorage.getItem(SETTINGS_KEY);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load voice settings:', e);
    }
    return DEFAULT_SETTINGS;
  });

  const [selectedCategory, setSelectedCategory] = useState<CategoryMode>('all');
  const [inputText, setInputText] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [listeningTranscript, setListeningTranscript] = useState('');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [currentlySpeakingMsgId, setCurrentlySpeakingMsgId] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [voiceModalOpen, setVoiceModalOpen] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showScrollBottom, setShowScrollBottom] = useState(false);

  // Refs
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const chatContainerRef = useRef<HTMLDivElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Active conversation object
  const activeConversation =
    conversations.find((c) => c.id === activeId) || conversations[0] || DEFAULT_CONVERSATION;

  // Persist conversations
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(conversations));
    } catch (e) {
      console.error('Failed to save conversations:', e);
    }
  }, [conversations]);

  // Persist settings
  useEffect(() => {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(voiceSettings));
    } catch (e) {
      console.error('Failed to save settings:', e);
    }
  }, [voiceSettings]);

  // Sync category with active conversation
  useEffect(() => {
    if (activeConversation.category) {
      setSelectedCategory(activeConversation.category);
    }
  }, [activeId]);

  // Auto scroll to bottom
  const scrollToBottom = (behavior: ScrollBehavior = 'smooth') => {
    messagesEndRef.current?.scrollIntoView({ behavior });
  };

  useEffect(() => {
    scrollToBottom();
  }, [activeConversation.messages.length, isGenerating]);

  // Handle scroll detection for scroll-to-bottom button
  const handleScroll = () => {
    if (!chatContainerRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = chatContainerRef.current;
    const distanceToBottom = scrollHeight - scrollTop - clientHeight;
    setShowScrollBottom(distanceToBottom > 150);
  };

  // Adjust textarea height dynamically
  const adjustTextareaHeight = () => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      const newHeight = Math.min(textareaRef.current.scrollHeight, 140);
      textareaRef.current.style.height = `${newHeight}px`;
    }
  };

  useEffect(() => {
    adjustTextareaHeight();
  }, [inputText]);

  // Android haptic feedback helper
  const triggerHaptic = () => {
    if (typeof window !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate?.([15]);
      } catch {
        // ignore
      }
    }
  };

  // Create new conversation
  const handleNewConversation = (cat: CategoryMode = selectedCategory) => {
    triggerHaptic();
    SpeechService.stopSpeaking();
    setIsSpeaking(false);
    setCurrentlySpeakingMsgId(null);

    const newId = `conv-${Date.now()}`;
    const newConv: Conversation = {
      id: newId,
      title: 'New Conversation',
      messages: [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
      category: cat,
    };

    setConversations((prev) => [newConv, ...prev]);
    setActiveId(newId);
    setSelectedCategory(cat);
    setErrorMessage(null);
  };

  // Delete conversation
  const handleDeleteConversation = (id: string) => {
    triggerHaptic();
    setConversations((prev) => {
      const remaining = prev.filter((c) => c.id !== id);
      if (remaining.length === 0) {
        return [DEFAULT_CONVERSATION];
      }
      return remaining;
    });

    if (activeId === id) {
      const remaining = conversations.filter((c) => c.id !== id);
      setActiveId(remaining[0]?.id || DEFAULT_CONVERSATION.id);
    }
  };

  // Rename conversation
  const handleRenameConversation = (id: string, newTitle: string) => {
    setConversations((prev) =>
      prev.map((c) => (c.id === id ? { ...c, title: newTitle, updatedAt: Date.now() } : c))
    );
  };

  // Clear all conversations
  const handleClearAll = () => {
    triggerHaptic();
    SpeechService.stopSpeaking();
    setIsSpeaking(false);
    setCurrentlySpeakingMsgId(null);
    setConversations([DEFAULT_CONVERSATION]);
    setActiveId(DEFAULT_CONVERSATION.id);
  };

  // Stop generation
  const handleStopGenerating = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsGenerating(false);
  };

  // Speech Recognition (Microphone)
  const toggleListening = () => {
    triggerHaptic();
    if (isListening) {
      SpeechService.stopListening();
      setIsListening(false);
      setListeningTranscript('');
    } else {
      setErrorMessage(null);
      // Stop any speech output first
      SpeechService.stopSpeaking();
      setIsSpeaking(false);
      setCurrentlySpeakingMsgId(null);

      const success = SpeechService.startListening({
        onStart: () => {
          setIsListening(true);
          setListeningTranscript('');
        },
        onResult: (transcript, isFinal) => {
          setListeningTranscript(transcript);
          if (isFinal) {
            setInputText((prev) => (prev ? `${prev} ${transcript}` : transcript));
            setIsListening(false);
            setListeningTranscript('');
          }
        },
        onError: (err) => {
          setIsListening(false);
          setListeningTranscript('');
          setErrorMessage(err);
        },
        onEnd: () => {
          setIsListening(false);
          setListeningTranscript('');
        },
      });

      if (!success) {
        setIsListening(false);
      }
    }
  };

  // Text-To-Speech (Speak Message)
  const toggleSpeakMessage = (msgId: string, text: string) => {
    triggerHaptic();
    if (currentlySpeakingMsgId === msgId && isSpeaking) {
      SpeechService.stopSpeaking();
      setIsSpeaking(false);
      setCurrentlySpeakingMsgId(null);
    } else {
      SpeechService.stopSpeaking();
      setIsSpeaking(true);
      setCurrentlySpeakingMsgId(msgId);

      SpeechService.speak(text, {
        voiceURI: voiceSettings.voiceURI,
        rate: voiceSettings.rate,
        pitch: voiceSettings.pitch,
        volume: voiceSettings.volume,
        onStart: () => {
          setIsSpeaking(true);
          setCurrentlySpeakingMsgId(msgId);
        },
        onEnd: () => {
          setIsSpeaking(false);
          setCurrentlySpeakingMsgId(null);
        },
        onError: () => {
          setIsSpeaking(false);
          setCurrentlySpeakingMsgId(null);
        },
      });
    }
  };

  // Send Message
  const handleSendMessage = async (textToSend?: string) => {
    const rawText = textToSend ?? inputText;
    const trimmed = rawText.trim();
    if (!trimmed || isGenerating) return;

    triggerHaptic();
    setErrorMessage(null);
    setInputText('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }

    // If currently listening, stop
    if (isListening) {
      SpeechService.stopListening();
      setIsListening(false);
      setListeningTranscript('');
    }

    const userMsgId = `msg-${Date.now()}`;
    const userMsg: Message = {
      id: userMsgId,
      role: 'user',
      content: trimmed,
      timestamp: Date.now(),
      status: 'complete',
    };

    // Auto generate title if first user message in conversation
    const isFirstUserMessage = activeConversation.messages.filter((m) => m.role === 'user').length === 0;
    const newTitle = isFirstUserMessage
      ? trimmed.slice(0, 32) + (trimmed.length > 32 ? '...' : '')
      : activeConversation.title;

    const assistantMsgId = `assistant-${Date.now()}`;
    const initialAssistantMsg: Message = {
      id: assistantMsgId,
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
      status: 'streaming',
    };

    const updatedMessages = [...activeConversation.messages, userMsg, initialAssistantMsg];

    setConversations((prev) =>
      prev.map((c) =>
        c.id === activeConversation.id
          ? {
              ...c,
              title: newTitle,
              messages: updatedMessages,
              updatedAt: Date.now(),
              category: selectedCategory,
            }
          : c
      )
    );

    setIsGenerating(true);

    const controller = new AbortController();
    abortControllerRef.current = controller;

    // Send only relevant messages (exclude empty streaming message)
    const apiMessages = [...activeConversation.messages, userMsg].map((m) => ({
      role: m.role,
      content: m.content,
    }));

    try {
      const response = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: apiMessages,
          category: selectedCategory !== 'all' ? selectedCategory : undefined,
        }),
        signal: controller.signal,
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Server responded with status ${response.status}`);
      }

      if (!response.body) {
        throw new Error('No readable response stream received.');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let accumulatedText = '';
      let buffer = '';

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const dataStr = line.slice(6).trim();
            if (dataStr === '[DONE]') {
              continue;
            }

            try {
              const parsed = JSON.parse(dataStr);
              if (parsed.text) {
                accumulatedText += parsed.text;
                setConversations((prev) =>
                  prev.map((c) =>
                    c.id === activeConversation.id
                      ? {
                          ...c,
                          messages: c.messages.map((m) =>
                            m.id === assistantMsgId
                              ? { ...m, content: accumulatedText, status: 'streaming' }
                              : m
                          ),
                        }
                      : c
                  )
                );
              } else if (parsed.error) {
                throw new Error(parsed.error);
              }
            } catch (err: any) {
              // Ignore partial JSON parse errors
              if (err.message && !err.message.includes('JSON')) {
                throw err;
              }
            }
          }
        }
      }

      // Mark message complete
      setConversations((prev) =>
        prev.map((c) =>
          c.id === activeConversation.id
            ? {
                ...c,
                messages: c.messages.map((m) =>
                  m.id === assistantMsgId ? { ...m, status: 'complete' } : m
                ),
              }
            : c
        )
      );

      // Auto-speak if setting is enabled
      if (voiceSettings.autoSpeak && accumulatedText) {
        toggleSpeakMessage(assistantMsgId, accumulatedText);
      }
    } catch (err: any) {
      if (err.name === 'AbortError') {
        // User deliberately stopped generation
        setConversations((prev) =>
          prev.map((c) =>
            c.id === activeConversation.id
              ? {
                  ...c,
                  messages: c.messages.map((m) =>
                    m.id === assistantMsgId ? { ...m, status: 'complete' } : m
                  ),
                }
              : c
          )
        );
      } else {
        console.error('Chat error:', err);
        const errMsg = err?.message || 'Failed to get answer from BRO AI.';
        setErrorMessage(errMsg);
        setConversations((prev) =>
          prev.map((c) =>
            c.id === activeConversation.id
              ? {
                  ...c,
                  messages: c.messages.map((m) =>
                    m.id === assistantMsgId
                      ? {
                          ...m,
                          content:
                            m.content ||
                            `⚠️ **Error communicating with BRO AI**\n\n${errMsg}\n\nPlease check your server connection or try asking again.`,
                          status: 'error',
                          errorMessage: errMsg,
                        }
                      : m
                  ),
                }
              : c
          )
        );
      }
    } finally {
      setIsGenerating(false);
      abortControllerRef.current = null;
    }
  };

  // Keyboard shortcut (Enter to send, Shift+Enter for newline)
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // Determine current orb state
  const orbStatus = isListening
    ? 'listening'
    : isGenerating
    ? 'thinking'
    : isSpeaking
    ? 'speaking'
    : 'idle';

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#070a13] text-slate-100 cyber-grid select-none">
      {/* Sidebar / Conversation Drawer */}
      <Sidebar
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        conversations={conversations}
        activeConversationId={activeConversation.id}
        onSelectConversation={(id) => setActiveId(id)}
        onNewConversation={handleNewConversation}
        onDeleteConversation={handleDeleteConversation}
        onRenameConversation={handleRenameConversation}
        onClearAll={handleClearAll}
        selectedCategory={selectedCategory}
        onSelectCategory={(cat) => setSelectedCategory(cat)}
        onOpenVoiceSettings={() => setVoiceModalOpen(true)}
      />

      {/* Main Chat View */}
      <div className="flex-1 flex flex-col h-full min-w-0 relative">
        {/* Top Navbar */}
        <header className="h-14 md:h-16 border-b border-slate-800/80 bg-slate-950/80 backdrop-blur-md px-3 md:px-6 flex items-center justify-between shrink-0 z-30 safe-top">
          <div className="flex items-center gap-2.5">
            {/* Mobile Hamburger Menu */}
            <button
              onClick={() => {
                triggerHaptic();
                setSidebarOpen(true);
              }}
              className="p-2 -ml-1 rounded-xl text-slate-400 hover:text-white hover:bg-slate-900 transition-colors md:hidden"
              aria-label="Open conversation history"
            >
              <Menu className="w-5 h-5" />
            </button>

            {/* BRO AI Logo & Status */}
            <div className="flex items-center gap-2">
              <div
                onClick={() => {
                  if (isSpeaking) {
                    SpeechService.stopSpeaking();
                    setIsSpeaking(false);
                    setCurrentlySpeakingMsgId(null);
                  } else {
                    toggleListening();
                  }
                }}
                className="cursor-pointer"
                title="Click to talk or stop audio"
              >
                <BROOrb status={orbStatus} size="sm" showLabel={false} />
              </div>

              <div>
                <div className="flex items-center gap-1.5">
                  <h1 className="text-sm md:text-base font-extrabold font-display tracking-tight text-white">
                    BRO <span className="text-cyan-400">AI</span>
                  </h1>
                  <span className="hidden sm:inline-block px-1.5 py-0.5 rounded text-[10px] font-mono bg-cyan-950 border border-cyan-800/50 text-cyan-300">
                    v1.0
                  </span>
                </div>
                <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-400">
                  <span
                    className={`w-1.5 h-1.5 rounded-full ${
                      isListening
                        ? 'bg-emerald-400 animate-ping'
                        : isGenerating
                        ? 'bg-cyan-400 animate-ping'
                        : isSpeaking
                        ? 'bg-purple-400 animate-pulse'
                        : 'bg-emerald-400'
                    }`}
                  />
                  <span>
                    {isListening
                      ? 'Listening...'
                      : isGenerating
                      ? 'Thinking...'
                      : isSpeaking
                      ? 'Speaking...'
                      : 'Online'}
                  </span>
                  <span className="hidden xs:inline">•</span>
                  <span className="hidden xs:inline text-cyan-400 capitalize">
                    {CATEGORIES[selectedCategory]?.name.split(' ')[0]} Mode
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Header Actions */}
          <div className="flex items-center gap-1 sm:gap-2">
            {/* Auto-Speak Quick Indicator */}
            <button
              onClick={() => {
                triggerHaptic();
                setVoiceSettings((prev) => ({ ...prev, autoSpeak: !prev.autoSpeak }));
              }}
              className={`p-2 rounded-xl border text-xs transition-colors flex items-center gap-1.5 ${
                voiceSettings.autoSpeak
                  ? 'bg-cyan-950/80 border-cyan-500/50 text-cyan-300'
                  : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
              title={
                voiceSettings.autoSpeak
                  ? 'Auto-Speak is ON (Click to mute)'
                  : 'Auto-Speak is OFF (Click to turn on)'
              }
            >
              {voiceSettings.autoSpeak ? (
                <Volume2 className="w-4 h-4 text-cyan-400 animate-pulse" />
              ) : (
                <VolumeX className="w-4 h-4" />
              )}
              <span className="hidden lg:inline text-[11px] font-mono">
                {voiceSettings.autoSpeak ? 'Voice ON' : 'Muted'}
              </span>
            </button>

            {/* Voice Settings Button */}
            <button
              onClick={() => {
                triggerHaptic();
                setVoiceModalOpen(true);
              }}
              className="p-2 rounded-xl bg-slate-900/60 hover:bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition-colors"
              title="Voice & Speech Settings"
            >
              <Sliders className="w-4 h-4" />
            </button>

            {/* New Chat Button */}
            <button
              onClick={() => handleNewConversation(selectedCategory)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20 transition-all active:scale-95"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span className="hidden sm:inline">New Chat</span>
            </button>
          </div>
        </header>

        {/* Global Error Banner */}
        {errorMessage && (
          <div className="px-4 py-2 bg-rose-950/90 border-b border-rose-800/80 text-rose-200 text-xs flex items-center justify-between shrink-0 z-20">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{errorMessage}</span>
            </div>
            <button
              onClick={() => setErrorMessage(null)}
              className="text-rose-400 hover:text-white px-1.5 py-0.5 rounded text-xs ml-2 font-mono"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Chat Scroll Area */}
        <div
          ref={chatContainerRef}
          onScroll={handleScroll}
          className="flex-1 overflow-y-auto px-3 sm:px-6 py-4 md:py-6 space-y-4 md:space-y-6"
        >
          {/* If conversation is empty, show welcome hero with holographic orb & quick prompts */}
          {activeConversation.messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center min-h-[70vh] text-center max-w-2xl mx-auto space-y-6 py-4">
              <BROOrb status={orbStatus} size="lg" showLabel={true} onClick={toggleListening} />

              <div className="space-y-2 px-4">
                <h2 className="text-2xl sm:text-3xl font-extrabold font-display tracking-tight text-white">
                  Meet <span className="bg-gradient-to-r from-cyan-400 via-sky-300 to-purple-400 bg-clip-text text-transparent">BRO AI</span>
                </h2>
                <p className="text-xs sm:text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
                  Your loyal, razor-sharp personal AI assistant. Ready for mathematics, schoolwork, deep research, and daily planning.
                </p>
              </div>

              {/* Quick Prompts */}
              <QuickPrompts
                category={selectedCategory}
                onSelectPrompt={(prompt) => handleSendMessage(prompt)}
                onSelectCategory={(cat) => setSelectedCategory(cat)}
              />
            </div>
          ) : (
            <div className="max-w-3xl mx-auto space-y-4 md:space-y-6">
              {activeConversation.messages.map((message) => {
                const isUser = message.role === 'user';
                const isThisSpeaking = currentlySpeakingMsgId === message.id && isSpeaking;

                return (
                  <div
                    key={message.id}
                    className={`flex items-start gap-2.5 sm:gap-3.5 ${
                      isUser ? 'flex-row-reverse' : 'flex-row'
                    }`}
                  >
                    {/* Avatar Icon */}
                    <div
                      className={`shrink-0 w-8 h-8 rounded-xl flex items-center justify-center shadow-md select-none ${
                        isUser
                          ? 'bg-gradient-to-br from-blue-600 to-indigo-700 text-white'
                          : 'bg-gradient-to-br from-cyan-500 to-blue-700 text-slate-950'
                      }`}
                    >
                      {isUser ? (
                        <User className="w-4 h-4 text-white" />
                      ) : (
                        <Sparkles className="w-4 h-4 text-slate-950 font-bold" />
                      )}
                    </div>

                    {/* Message Bubble */}
                    <div
                      className={`max-w-[85%] sm:max-w-[78%] rounded-2xl p-3.5 sm:p-4 text-sm leading-relaxed transition-all shadow-lg ${
                        isUser
                          ? 'bg-blue-600/90 text-white border border-blue-400/30 rounded-tr-sm ml-auto'
                          : 'glass-card border border-slate-700/60 rounded-tl-sm text-slate-100'
                      }`}
                    >
                      {/* Assistant Header Badge */}
                      {!isUser && (
                        <div className="flex items-center justify-between gap-2 mb-2 pb-1.5 border-b border-slate-800/80">
                          <div className="flex items-center gap-1.5">
                            <span className="font-display font-bold text-xs text-cyan-300">
                              BRO AI
                            </span>
                            {message.status === 'streaming' && (
                              <span className="text-[10px] text-cyan-400 font-mono flex items-center gap-1">
                                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
                                writing...
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] font-mono text-slate-400">
                            {new Date(message.timestamp).toLocaleTimeString([], {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                        </div>
                      )}

                      {/* Message Content */}
                      <MarkdownMessage
                        content={message.content}
                        isAssistant={!isUser}
                        isSpeakingThis={isThisSpeaking}
                        onToggleSpeak={
                          !isUser && message.content
                            ? () => toggleSpeakMessage(message.id, message.content)
                            : undefined
                        }
                      />
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Scroll To Bottom Button */}
        {showScrollBottom && (
          <button
            onClick={() => scrollToBottom()}
            className="absolute right-4 bottom-28 z-30 p-2.5 rounded-full bg-slate-900/90 hover:bg-slate-800 text-cyan-400 border border-slate-700 shadow-xl transition-all hover:scale-105 active:scale-95"
            title="Scroll to bottom"
          >
            <ArrowDown className="w-4 h-4" />
          </button>
        )}

        {/* Active Speech Recognition Banner */}
        {isListening && (
          <div className="mx-3 sm:mx-6 mb-2 p-2.5 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-200 text-xs flex items-center justify-between shadow-lg shadow-emerald-950/50 animate-pulse z-20">
            <div className="flex items-center gap-2 min-w-0">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping shrink-0" />
              <div className="truncate">
                <span className="font-bold text-white mr-1.5">Listening:</span>
                <span className="italic text-emerald-200 font-mono">
                  {listeningTranscript || 'Speak now...'}
                </span>
              </div>
            </div>
            <button
              onClick={() => {
                SpeechService.stopListening();
                setIsListening(false);
                if (listeningTranscript) {
                  handleSendMessage(listeningTranscript);
                  setListeningTranscript('');
                }
              }}
              className="ml-2 px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-[11px] shrink-0"
            >
              Done
            </button>
          </div>
        )}

        {/* Bottom Input Area */}
        <div className="p-3 sm:p-4 bg-slate-950/95 border-t border-slate-800/80 safe-bottom shrink-0 z-20">
          <div className="max-w-3xl mx-auto">
            {/* Quick Mode Chips Row */}
            <div className="flex items-center justify-between mb-2 px-1 text-[11px]">
              <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none no-scrollbar">
                <span className="text-slate-400 font-mono uppercase text-[10px] hidden sm:inline">
                  Mode:
                </span>
                {(['all', 'math', 'study', 'research', 'code', 'tasks'] as CategoryMode[]).map(
                  (catKey) => {
                    const isSelected = selectedCategory === catKey;
                    return (
                      <button
                        key={catKey}
                        onClick={() => setSelectedCategory(catKey)}
                        className={`px-2 py-0.5 rounded-md text-[11px] font-medium transition-colors ${
                          isSelected
                            ? 'bg-cyan-950 border border-cyan-500/50 text-cyan-300 font-semibold'
                            : 'text-slate-400 hover:text-slate-300'
                        }`}
                      >
                        {CATEGORIES[catKey]?.name.split(' ')[0]}
                      </button>
                    );
                  }
                )}
              </div>

              {/* Stop Generating Button */}
              {isGenerating && (
                <button
                  onClick={handleStopGenerating}
                  className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-rose-950/80 border border-rose-800/60 text-rose-300 hover:bg-rose-900 transition-colors shrink-0"
                >
                  <Square className="w-3 h-3 fill-current" />
                  <span>Stop</span>
                </button>
              )}
            </div>

            {/* Input Bar Container */}
            <div className="relative flex items-end gap-2 bg-slate-900/90 border border-slate-700/80 focus-within:border-cyan-400/80 rounded-2xl p-1.5 sm:p-2 shadow-2xl transition-all">
              {/* Voice / Mic Button */}
              <button
                type="button"
                onClick={toggleListening}
                className={`p-2.5 rounded-xl transition-all flex items-center justify-center shrink-0 ${
                  isListening
                    ? 'bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/50 animate-pulse scale-105'
                    : 'text-slate-400 hover:text-cyan-300 hover:bg-slate-800 active:scale-95'
                }`}
                title={isListening ? 'Stop listening' : 'Speak to BRO (Microphone)'}
                aria-label="Microphone Voice Input"
              >
                {isListening ? (
                  <MicOff className="w-5 h-5 stroke-[2.5]" />
                ) : (
                  <Mic className="w-5 h-5 stroke-[2]" />
                )}
              </button>

              {/* Text Input Area */}
              <textarea
                ref={textareaRef}
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={
                  isListening
                    ? 'Listening to you... speak your question!'
                    : `Ask BRO anything (${CATEGORIES[selectedCategory]?.name})...`
                }
                rows={1}
                className="flex-1 max-h-36 bg-transparent text-slate-100 placeholder-slate-500 text-sm md:text-base resize-none focus:outline-none py-2 px-1 leading-relaxed"
              />

              {/* Send Button */}
              <button
                type="button"
                onClick={() => handleSendMessage()}
                disabled={!inputText.trim() || isGenerating}
                className={`p-2.5 rounded-xl transition-all flex items-center justify-center shrink-0 ${
                  inputText.trim() && !isGenerating
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 shadow-md shadow-cyan-500/30 scale-100 active:scale-95'
                    : 'bg-slate-800/60 text-slate-600 cursor-not-allowed'
                }`}
                title="Send message"
                aria-label="Send message"
              >
                <Send className="w-4 h-4 stroke-[2.5]" />
              </button>
            </div>

            {/* Android Voice & Mobile Hint */}
            <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono mt-1.5 px-2">
              <span className="hidden sm:inline">Press Enter to send, Shift+Enter for new line</span>
              <span className="sm:hidden">Tap Mic to speak to BRO</span>
              <span>Tap BRO Orb anytime for voice</span>
            </div>
          </div>
        </div>
      </div>

      {/* Voice Settings Dialog */}
      <VoiceModal
        isOpen={voiceModalOpen}
        onClose={() => setVoiceModalOpen(false)}
        settings={voiceSettings}
        onSave={(newSettings) => setVoiceSettings(newSettings)}
      />
    </div>
  );
}
