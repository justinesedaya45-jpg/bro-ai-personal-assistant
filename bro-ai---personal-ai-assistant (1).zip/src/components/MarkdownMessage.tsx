import React, { useState } from 'react';
import { Copy, Check, Volume2, Square, Sparkles } from 'lucide-react';

interface MarkdownMessageProps {
  content: string;
  isAssistant: boolean;
  isSpeakingThis?: boolean;
  onToggleSpeak?: () => void;
}

export const MarkdownMessage: React.FC<MarkdownMessageProps> = ({
  content,
  isAssistant,
  isSpeakingThis,
  onToggleSpeak,
}) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [copiedAll, setCopiedAll] = useState(false);

  const copyToClipboard = (text: string, index?: number) => {
    navigator.clipboard.writeText(text);
    if (index !== undefined) {
      setCopiedIndex(index);
      setTimeout(() => setCopiedIndex(null), 2000);
    } else {
      setCopiedAll(true);
      setTimeout(() => setCopiedAll(false), 2000);
    }
  };

  // Parser helper to split markdown into blocks (code blocks vs formatted text)
  const renderFormattedContent = () => {
    // Check for code blocks ```lang ... ```
    const codeBlockRegex = /```([a-zA-Z0-9_-]*)\n([\s\S]*?)```/g;
    const parts: React.ReactNode[] = [];
    let lastIndex = 0;
    let match: RegExpExecArray | null;
    let blockCounter = 0;

    while ((match = codeBlockRegex.exec(content)) !== null) {
      const textBefore = content.substring(lastIndex, match.index);
      if (textBefore) {
        parts.push(renderTextBlock(textBefore, `text-${lastIndex}`));
      }

      const language = match[1] || 'code';
      const code = match[2];
      const currentBlockIndex = blockCounter++;

      parts.push(
        <div
          key={`code-${match.index}`}
          className="my-3 rounded-xl overflow-hidden border border-slate-700/80 bg-slate-950/90 shadow-xl"
        >
          <div className="flex items-center justify-between px-3.5 py-1.5 bg-slate-900/90 border-b border-slate-800 text-xs font-mono text-slate-400">
            <span className="uppercase text-cyan-400 font-semibold tracking-wider text-[11px]">
              {language}
            </span>
            <button
              onClick={() => copyToClipboard(code, currentBlockIndex)}
              className="flex items-center gap-1.5 px-2 py-0.5 rounded hover:bg-slate-800 text-slate-300 hover:text-white transition-colors text-[11px]"
              title="Copy code"
            >
              {copiedIndex === currentBlockIndex ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy</span>
                </>
              )}
            </button>
          </div>
          <pre className="p-3.5 overflow-x-auto text-xs md:text-sm font-mono text-emerald-300/90 leading-relaxed">
            <code>{code}</code>
          </pre>
        </div>
      );

      lastIndex = match.index + match[0].length;
    }

    if (lastIndex < content.length) {
      parts.push(renderTextBlock(content.substring(lastIndex), `text-${lastIndex}`));
    }

    return parts;
  };

  // Helper for inline styles (bold, headers, bullets, inline code)
  const renderTextBlock = (text: string, keyPrefix: string) => {
    const lines = text.split('\n');
    return (
      <div key={keyPrefix} className="space-y-1.5 leading-relaxed">
        {lines.map((line, idx) => {
          const trimmed = line.trim();

          // Math step / block indicator: e.g. "Step 1:", "Calculation:"
          if (/^(Step \d+|Method \d+|Phase \d+|Solution|Calculation):/i.test(trimmed)) {
            return (
              <div
                key={`${keyPrefix}-${idx}`}
                className="font-display font-semibold text-cyan-300 text-sm md:text-base mt-2 flex items-center gap-2"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                {parseInlineFormatting(line)}
              </div>
            );
          }

          // Headers
          if (line.startsWith('### ')) {
            return (
              <h3
                key={`${keyPrefix}-${idx}`}
                className="text-base md:text-lg font-bold text-cyan-300 mt-2.5 mb-1 font-display"
              >
                {parseInlineFormatting(line.slice(4))}
              </h3>
            );
          }
          if (line.startsWith('## ')) {
            return (
              <h2
                key={`${keyPrefix}-${idx}`}
                className="text-lg md:text-xl font-bold text-sky-200 mt-3 mb-1.5 font-display border-b border-slate-700/50 pb-1"
              >
                {parseInlineFormatting(line.slice(3))}
              </h2>
            );
          }
          if (line.startsWith('# ')) {
            return (
              <h1
                key={`${keyPrefix}-${idx}`}
                className="text-xl md:text-2xl font-extrabold text-white mt-3.5 mb-2 font-display"
              >
                {parseInlineFormatting(line.slice(2))}
              </h1>
            );
          }

          // Bullet list items
          if (/^[-*+]\s+/.test(line)) {
            const contentPart = line.replace(/^[-*+]\s+/, '');
            return (
              <div key={`${keyPrefix}-${idx}`} className="flex items-start gap-2.5 ml-1.5 my-1">
                <span className="text-cyan-400 mt-1.5 text-xs">◆</span>
                <span className="text-slate-200">{parseInlineFormatting(contentPart)}</span>
              </div>
            );
          }

          // Numbered list items
          if (/^\d+\.\s+/.test(line)) {
            const match = line.match(/^(\d+)\.\s+(.*)/);
            if (match) {
              return (
                <div key={`${keyPrefix}-${idx}`} className="flex items-start gap-2.5 ml-1 my-1">
                  <span className="text-cyan-400 font-mono text-xs font-semibold px-1.5 py-0.5 rounded bg-cyan-950/60 border border-cyan-800/40 shrink-0">
                    {match[1]}
                  </span>
                  <span className="text-slate-200">{parseInlineFormatting(match[2])}</span>
                </div>
              );
            }
          }

          // Blockquote
          if (line.startsWith('> ')) {
            return (
              <blockquote
                key={`${keyPrefix}-${idx}`}
                className="border-l-2 border-cyan-400/80 bg-cyan-950/20 pl-3 py-1 my-1.5 italic text-slate-300 text-sm rounded-r"
              >
                {parseInlineFormatting(line.slice(2))}
              </blockquote>
            );
          }

          // Empty line
          if (!trimmed) {
            return <div key={`${keyPrefix}-${idx}`} className="h-1.5" />;
          }

          // Regular paragraph line
          return (
            <p key={`${keyPrefix}-${idx}`} className="text-slate-200">
              {parseInlineFormatting(line)}
            </p>
          );
        })}
      </div>
    );
  };

  // Helper to parse bold (**), inline code (`), and italic (*)
  const parseInlineFormatting = (text: string): React.ReactNode => {
    // Regex matches inline code `...`, bold **...**, math $...$, italic *...*
    const tokens = text.split(/(`[^`]+`|\*\*[^*]+\*\*|\$[^\$]+\$)/g);

    return tokens.map((token, i) => {
      if (token.startsWith('`') && token.endsWith('`') && token.length > 2) {
        return (
          <code
            key={i}
            className="px-1.5 py-0.5 mx-0.5 rounded bg-slate-900 border border-slate-700 text-cyan-300 font-mono text-xs font-medium"
          >
            {token.slice(1, -1)}
          </code>
        );
      }
      if (token.startsWith('**') && token.endsWith('**') && token.length > 4) {
        return (
          <strong key={i} className="font-bold text-white tracking-wide">
            {token.slice(2, -2)}
          </strong>
        );
      }
      if (token.startsWith('$') && token.endsWith('$') && token.length > 2) {
        return (
          <span
            key={i}
            className="px-1.5 py-0.5 mx-0.5 rounded bg-cyan-950/50 border border-cyan-800/40 text-emerald-300 font-mono text-xs font-semibold"
          >
            {token.slice(1, -1)}
          </span>
        );
      }
      return token;
    });
  };

  return (
    <div className="relative group text-sm md:text-base">
      <div className="overflow-hidden">{renderFormattedContent()}</div>

      {/* Action footer for assistant messages */}
      {isAssistant && (
        <div className="flex items-center gap-2 mt-3 pt-2.5 border-t border-slate-800/60 text-xs text-slate-400">
          {onToggleSpeak && (
            <button
              onClick={onToggleSpeak}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition-all border ${
                isSpeakingThis
                  ? 'bg-purple-950/80 border-purple-500 text-purple-300 shadow-md shadow-purple-900/40 animate-pulse'
                  : 'bg-slate-900/70 border-slate-800 text-slate-400 hover:text-cyan-300 hover:border-cyan-500/40'
              }`}
              title={isSpeakingThis ? 'Stop speaking' : 'Listen with BRO voice'}
            >
              {isSpeakingThis ? (
                <>
                  <Square className="w-3.5 h-3.5 fill-current text-purple-400" />
                  <span className="font-medium text-purple-300">Speaking... Stop</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>Listen</span>
                </>
              )}
            </button>
          )}

          <button
            onClick={() => copyToClipboard(content)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900/70 border border-slate-800 text-slate-400 hover:text-white hover:border-slate-700 transition-colors"
            title="Copy answer"
          >
            {copiedAll ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400 font-medium">Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy</span>
              </>
            )}
          </button>
        </div>
      )}
    </div>
  );
};
