import React from 'react';
import { Mic, Volume2, Sparkles, Loader2 } from 'lucide-react';

interface BROOrbProps {
  status: 'idle' | 'listening' | 'thinking' | 'speaking';
  onClick?: () => void;
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
}

export const BROOrb: React.FC<BROOrbProps> = ({
  status,
  onClick,
  size = 'md',
  showLabel = true,
}) => {
  const sizeClasses = {
    sm: 'w-10 h-10',
    md: 'w-20 h-20 md:w-24 md:h-24',
    lg: 'w-28 h-28 md:w-36 md:h-36',
  };

  const getStatusText = () => {
    switch (status) {
      case 'listening':
        return 'LISTENING TO YOU...';
      case 'thinking':
        return 'BRO IS PROCESSING...';
      case 'speaking':
        return 'BRO IS SPEAKING';
      default:
        return 'BRO AI READY';
    }
  };

  const getStatusColor = () => {
    switch (status) {
      case 'listening':
        return 'text-emerald-400 bg-emerald-950/40 border-emerald-500/30';
      case 'thinking':
        return 'text-cyan-400 bg-cyan-950/40 border-cyan-500/30';
      case 'speaking':
        return 'text-purple-400 bg-purple-950/40 border-purple-500/30';
      default:
        return 'text-sky-400 bg-sky-950/30 border-sky-500/20';
    }
  };

  return (
    <div className="flex flex-col items-center justify-center select-none">
      <div
        onClick={onClick}
        className={`relative ${sizeClasses[size]} rounded-full flex items-center justify-center cursor-pointer transition-all duration-500 group`}
        role="button"
        tabIndex={0}
        aria-label={`BRO AI Core - ${status}`}
      >
        {/* Outer Glow Ring */}
        <div
          className={`absolute -inset-3 rounded-full blur-xl opacity-60 transition-all duration-700 ${
            status === 'listening'
              ? 'bg-emerald-500/40 animate-pulse'
              : status === 'thinking'
              ? 'bg-gradient-to-r from-cyan-500 to-purple-600 animate-spin opacity-75'
              : status === 'speaking'
              ? 'bg-purple-500/50 animate-pulse'
              : 'bg-cyan-500/25 group-hover:opacity-80'
          }`}
        />

        {/* Outer Cybernetic Ring */}
        <div
          className={`absolute inset-0 rounded-full border border-dashed transition-all duration-1000 ${
            status === 'listening'
              ? 'border-emerald-400/60 animate-[spin_4s_linear_infinite]'
              : status === 'thinking'
              ? 'border-cyan-400/80 animate-[spin_2s_linear_infinite]'
              : status === 'speaking'
              ? 'border-purple-400/70 animate-[spin_6s_linear_infinite]'
              : 'border-cyan-500/30 group-hover:border-cyan-400/60 animate-[spin_20s_linear_infinite]'
          }`}
        />

        {/* Middle Glowing Ring */}
        <div
          className={`absolute inset-1.5 rounded-full border transition-all duration-500 ${
            status === 'listening'
              ? 'border-emerald-400/40 scale-105'
              : status === 'thinking'
              ? 'border-cyan-400/40 scale-105'
              : status === 'speaking'
              ? 'border-purple-400/40 scale-110'
              : 'border-cyan-500/20'
          }`}
        />

        {/* Core Sphere */}
        <div
          className={`relative z-10 w-full h-full rounded-full flex items-center justify-center overflow-hidden transition-transform duration-300 shadow-2xl ${
            status === 'listening'
              ? 'bg-gradient-to-br from-emerald-600 via-teal-700 to-cyan-900 shadow-emerald-500/50 scale-105'
              : status === 'thinking'
              ? 'bg-gradient-to-br from-cyan-600 via-indigo-700 to-purple-900 shadow-cyan-500/50'
              : status === 'speaking'
              ? 'bg-gradient-to-br from-purple-600 via-indigo-700 to-cyan-900 shadow-purple-500/50 scale-105'
              : 'bg-gradient-to-br from-cyan-900/90 via-slate-900 to-sky-950 shadow-cyan-500/20 group-hover:scale-105'
          }`}
        >
          {/* Internal Shimmer Texture */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-white/30 via-transparent to-transparent pointer-events-none" />

          {/* Central Animated Icon or Soundwaves */}
          {status === 'listening' && (
            <div className="flex items-center gap-1 z-10">
              <span className="w-1 bg-emerald-200 rounded-full animate-[listeningWave_0.6s_ease-in-out_infinite]" />
              <span className="w-1 bg-emerald-200 rounded-full animate-[listeningWave_0.9s_ease-in-out_infinite_0.1s]" />
              <span className="w-1.5 bg-white rounded-full animate-[listeningWave_0.7s_ease-in-out_infinite_0.2s]" />
              <span className="w-1 bg-emerald-200 rounded-full animate-[listeningWave_0.8s_ease-in-out_infinite_0.3s]" />
              <span className="w-1 bg-emerald-200 rounded-full animate-[listeningWave_0.6s_ease-in-out_infinite_0.15s]" />
            </div>
          )}

          {status === 'thinking' && (
            <div className="flex items-center justify-center z-10">
              <Loader2 className="w-6 h-6 md:w-8 md:h-8 text-cyan-200 animate-spin" />
            </div>
          )}

          {status === 'speaking' && (
            <div className="flex items-center gap-1 z-10">
              <span className="w-1 bg-purple-200 rounded-full animate-[listeningWave_0.5s_ease-in-out_infinite]" />
              <span className="w-1.5 bg-white rounded-full animate-[listeningWave_0.8s_ease-in-out_infinite_0.1s]" />
              <span className="w-1 bg-purple-200 rounded-full animate-[listeningWave_0.6s_ease-in-out_infinite_0.2s]" />
              <Volume2 className="w-4 h-4 text-purple-100 mx-0.5" />
            </div>
          )}

          {status === 'idle' && (
            <div className="flex items-center justify-center z-10 text-cyan-300 group-hover:text-white transition-colors">
              <Sparkles className="w-5 h-5 md:w-7 md:h-7 animate-pulse" />
            </div>
          )}
        </div>
      </div>

      {showLabel && (
        <div
          className={`mt-2.5 px-3 py-1 rounded-full text-[10px] md:text-xs font-mono font-semibold tracking-wider uppercase border transition-all duration-300 flex items-center gap-1.5 ${getStatusColor()}`}
        >
          <span
            className={`w-1.5 h-1.5 rounded-full ${
              status === 'listening'
                ? 'bg-emerald-400 animate-ping'
                : status === 'thinking'
                ? 'bg-cyan-400 animate-ping'
                : status === 'speaking'
                ? 'bg-purple-400 animate-pulse'
                : 'bg-sky-400'
            }`}
          />
          {getStatusText()}
        </div>
      )}
    </div>
  );
};
