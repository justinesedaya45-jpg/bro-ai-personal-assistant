import React, { useState, useEffect } from 'react';
import { X, Volume2, Play, RotateCcw, Check, Sliders, Smartphone } from 'lucide-react';
import { VoiceSettings } from '../types';
import { SpeechService } from '../services/speech';

interface VoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: VoiceSettings;
  onSave: (newSettings: VoiceSettings) => void;
}

export const VoiceModal: React.FC<VoiceModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSave,
}) => {
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoiceURI, setSelectedVoiceURI] = useState(settings.voiceURI);
  const [rate, setRate] = useState(settings.rate);
  const [pitch, setPitch] = useState(settings.pitch);
  const [autoSpeak, setAutoSpeak] = useState(settings.autoSpeak);
  const [previewing, setPreviewing] = useState(false);

  useEffect(() => {
    SpeechService.getVoices().then((loadedVoices) => {
      setVoices(loadedVoices);
      if (!selectedVoiceURI && loadedVoices.length > 0) {
        // Default to a natural English voice if possible
        const defaultVoice = loadedVoices.find(
          (v) =>
            v.lang.startsWith('en') &&
            (v.name.includes('Google') || v.name.includes('Natural') || v.name.includes('Samantha'))
        ) || loadedVoices[0];
        if (defaultVoice) {
          setSelectedVoiceURI(defaultVoice.voiceURI);
        }
      }
    });
  }, [selectedVoiceURI]);

  if (!isOpen) return null;

  const handleTestVoice = () => {
    SpeechService.stopSpeaking();
    setPreviewing(true);
    const testText = "Yo! I am BRO, your personal AI assistant. Let's solve some math, do research, or tackle your schoolwork together!";
    SpeechService.speak(testText, {
      voiceURI: selectedVoiceURI,
      rate: rate,
      pitch: pitch,
      onEnd: () => setPreviewing(false),
      onError: () => setPreviewing(false),
    });
  };

  const handleReset = () => {
    setRate(1.0);
    setPitch(1.0);
    setAutoSpeak(false);
  };

  const handleSaveAndClose = () => {
    onSave({
      voiceURI: selectedVoiceURI,
      rate,
      pitch,
      autoSpeak,
      volume: 1.0,
    });
    SpeechService.stopSpeaking();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl p-5 md:p-6 text-slate-100 overflow-hidden">
        {/* Glow ambient background */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-950/70 border border-cyan-500/30 text-cyan-400">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold font-display text-white">Voice & Speech Settings</h2>
              <p className="text-xs text-slate-400">Customize how BRO speaks to you</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="mt-5 space-y-5">
          {/* Auto Speak Toggle */}
          <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <div>
              <div className="text-sm font-semibold text-white">Auto-Speak Responses</div>
              <div className="text-xs text-slate-400 mt-0.5">
                Automatically read BRO's answers out loud
              </div>
            </div>
            <button
              type="button"
              onClick={() => setAutoSpeak(!autoSpeak)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${
                autoSpeak ? 'bg-cyan-500' : 'bg-slate-700'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  autoSpeak ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Voice Selector */}
          <div>
            <label className="block text-xs font-semibold uppercase font-mono tracking-wider text-cyan-400 mb-1.5">
              BRO Voice Model ({voices.length} available)
            </label>
            <select
              value={selectedVoiceURI}
              onChange={(e) => setSelectedVoiceURI(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-slate-200 focus:outline-none focus:border-cyan-400"
            >
              {voices.map((v) => (
                <option key={v.voiceURI} value={v.voiceURI}>
                  {v.name} ({v.lang}) {v.default ? '★ Default' : ''}
                </option>
              ))}
            </select>
          </div>

          {/* Speed / Rate Slider */}
          <div>
            <div className="flex items-center justify-between text-xs mb-1.5">
              <span className="font-semibold text-slate-300">Speaking Speed</span>
              <span className="font-mono text-cyan-400 font-semibold">{rate.toFixed(2)}x</span>
            </div>
            <input
              type="range"
              min="0.7"
              max="1.5"
              step="0.05"
              value={rate}
              onChange={(e) => setRate(parseFloat(e.target.value))}
              className="w-full accent-cyan-400 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-0.5">
              <span>Slower (0.7x)</span>
              <span>Normal (1.0x)</span>
              <span>Faster (1.5x)</span>
            </div>
          </div>

          {/* Pitch Slider */}
          <div>
            <div className="flex items-center justify-between text-xs mb-1.5">
              <span className="font-semibold text-slate-300">Voice Pitch / Tone</span>
              <span className="font-mono text-cyan-400 font-semibold">{pitch.toFixed(2)}</span>
            </div>
            <input
              type="range"
              min="0.8"
              max="1.3"
              step="0.05"
              value={pitch}
              onChange={(e) => setPitch(parseFloat(e.target.value))}
              className="w-full accent-cyan-400 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-0.5">
              <span>Deeper</span>
              <span>Balanced</span>
              <span>Higher</span>
            </div>
          </div>

          {/* Android Voice Tip */}
          <div className="flex items-start gap-2.5 p-3 rounded-xl bg-cyan-950/30 border border-cyan-800/30 text-xs text-cyan-200">
            <Smartphone className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
            <span>
              On Android phones, BRO uses your device's built-in Google Speech engine for crystal-clear, zero-lag voice.
            </span>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between mt-6 pt-4 border-t border-slate-800">
          <div className="flex items-center gap-2">
            <button
              onClick={handleTestVoice}
              disabled={previewing}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 hover:text-white transition-colors border border-slate-700"
            >
              <Play className="w-3.5 h-3.5 text-cyan-400" />
              <span>{previewing ? 'Testing...' : 'Test Voice'}</span>
            </button>
            <button
              onClick={handleReset}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              title="Reset sliders"
            >
              <RotateCcw className="w-3 h-3" />
            </button>
          </div>

          <button
            onClick={handleSaveAndClose}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-xs font-semibold text-slate-950 shadow-lg shadow-cyan-500/25 transition-all"
          >
            <Check className="w-4 h-4" />
            <span>Save Settings</span>
          </button>
        </div>
      </div>
    </div>
  );
};
