import React from 'react';
import { Sparkles, ArrowUpRight, Calculator, GraduationCap, Compass, Code, CheckCircle2 } from 'lucide-react';
import { CategoryMode } from '../types';
import { CATEGORIES } from '../data/categories';

interface QuickPromptsProps {
  category: CategoryMode;
  onSelectPrompt: (promptText: string) => void;
  onSelectCategory: (category: CategoryMode) => void;
}

export const QuickPrompts: React.FC<QuickPromptsProps> = ({
  category,
  onSelectPrompt,
  onSelectCategory,
}) => {
  const currentCategoryInfo = CATEGORIES[category] || CATEGORIES.all;

  const getIcon = (catId: CategoryMode) => {
    switch (catId) {
      case 'math':
        return <Calculator className="w-4 h-4 text-emerald-400" />;
      case 'study':
        return <GraduationCap className="w-4 h-4 text-blue-400" />;
      case 'research':
        return <Compass className="w-4 h-4 text-purple-400" />;
      case 'code':
        return <Code className="w-4 h-4 text-amber-400" />;
      case 'tasks':
        return <CheckCircle2 className="w-4 h-4 text-cyan-400" />;
      default:
        return <Sparkles className="w-4 h-4 text-cyan-400" />;
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto px-4 py-4 space-y-4">
      {/* Category Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none no-scrollbar">
        {Object.values(CATEGORIES).map((cat) => {
          const isActive = cat.id === category;
          return (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all border ${
                isActive
                  ? 'bg-cyan-950 border-cyan-400 text-cyan-300 shadow-md shadow-cyan-950'
                  : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
              }`}
            >
              {getIcon(cat.id)}
              <span>{cat.name}</span>
            </button>
          );
        })}
      </div>

      {/* Mode Description */}
      <div className="text-center">
        <p className="text-xs text-slate-400 max-w-md mx-auto">
          {currentCategoryInfo.description}
        </p>
      </div>

      {/* Suggested Prompt Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        {currentCategoryInfo.prompts.map((item, idx) => (
          <button
            key={idx}
            onClick={() => onSelectPrompt(item.prompt)}
            className="group text-left p-3.5 rounded-xl bg-slate-900/70 hover:bg-slate-900 border border-slate-800/80 hover:border-cyan-500/40 transition-all shadow-md hover:shadow-cyan-950 active:scale-[0.99] flex flex-col justify-between"
          >
            <div className="flex items-center justify-between gap-2 mb-1.5">
              <span className="text-xs font-semibold text-cyan-300 group-hover:text-cyan-200 font-display">
                {item.title}
              </span>
              <ArrowUpRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-cyan-400 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </div>
            <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
              {item.prompt}
            </p>
          </button>
        ))}
      </div>
    </div>
  );
};
