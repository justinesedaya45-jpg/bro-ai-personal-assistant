export type Role = 'user' | 'assistant';

export interface Message {
  id: string;
  role: Role;
  content: string;
  timestamp: number;
  category?: string;
  status?: 'sending' | 'streaming' | 'complete' | 'error';
  errorMessage?: string;
}

export interface Conversation {
  id: string;
  title: string;
  messages: Message[];
  createdAt: number;
  updatedAt: number;
  category?: CategoryMode;
}

export type CategoryMode = 'all' | 'math' | 'study' | 'research' | 'code' | 'tasks';

export interface CategoryInfo {
  id: CategoryMode;
  name: string;
  iconName: string;
  description: string;
  color: string;
  prompts: { title: string; prompt: string }[];
}

export interface VoiceSettings {
  autoSpeak: boolean;
  voiceURI: string;
  rate: number;
  pitch: number;
  volume: number;
}
