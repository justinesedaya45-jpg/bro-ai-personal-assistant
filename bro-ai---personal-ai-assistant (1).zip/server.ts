import express from 'express';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '10mb' }));

// Initialize GoogleGenAI server-side with User-Agent telemetry
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

const BRO_SYSTEM_INSTRUCTION = `You are BRO (Brain-Responsive Oracle), the user's personal, futuristic, highly intelligent AI assistant.
Personality & Persona:
- You are exceptionally smart, friendly, warm, respectful, and motivating.
- You treat the user like a valued partner, student, or peer: enthusiastic to help, never condescending, always polite and encouraging.
- You have an authentic, confident voice—like a brilliant mentor and loyal companion rolled into one.
- You can naturally refer to the user in a friendly way when fitting, but keep the focus on delivering top-tier answers.

Core Capabilities:
1. Mathematics & Science: Provide clear step-by-step calculations, intuitive explanations, definitions, formulas, and real-world examples.
2. Schoolwork & Academics: Break down complex concepts, assist with essays, history, literature, study tips, quiz prep, and exam review.
3. Research & Knowledge: Deliver factual, well-organized answers, historical context, technological insights, and pros/cons.
4. Coding & Tech: Write clean, commented, modern code with explanations for debugging and logic.
5. Everyday Life & Productivity: Daily planning, workout plans, time management, polite emails, brainstorming, and creative tasks.

Formatting Rules:
- Use clean Markdown with headers, bullet points, and code blocks for readability.
- For math formulas, format clearly using clear step-by-step blocks.
- Keep spoken clarity in mind so that answers sound great when read aloud via Text-to-Speech.
- If asked who you are, proudly introduce yourself as BRO AI, their futuristic personal AI assistant.`;

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    hasKey: Boolean(process.env.GEMINI_API_KEY),
    timestamp: new Date().toISOString(),
  });
});

// Chat endpoint (Standard JSON)
app.post('/api/chat', async (req, res) => {
  try {
    const { messages, category, customPrompt } = req.body;

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'Messages array is required' });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({
        error: 'GEMINI_API_KEY is not configured on the server. Please check the Secrets panel.',
      });
    }

    // Build contents from history
    // Gemini API supports contents array with role: 'user' | 'model' and parts: [{ text }]
    const contents = messages.map((m: { role: string; content: string }) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }],
    }));

    let sysInstruction = BRO_SYSTEM_INSTRUCTION;
    if (category) {
      sysInstruction += `\nCurrent user focus mode: ${category}. Tailor responses specifically with deep expertise in this domain.`;
    }
    if (customPrompt) {
      sysInstruction += `\nAdditional user preference: ${customPrompt}`;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: contents,
      config: {
        systemInstruction: sysInstruction,
      },
    });

    const replyText = response.text || "I'm here for you, but I couldn't generate a text response just now. Let's try again!";

    return res.json({
      role: 'assistant',
      content: replyText,
    });
  } catch (error: any) {
    console.error('Gemini chat error:', error);
    const errorMessage = error?.message || 'Failed to communicate with BRO AI.';
    const status = error?.status || 500;
    return res.status(status).json({
      error: errorMessage,
      details: error?.errorDetails || undefined,
    });
  }
});

// Streaming Chat endpoint (Server-Sent Events)
app.post('/api/chat/stream', async (req, res) => {
  try {
    const { messages, category, customPrompt } = req.body;

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'Messages array is required' });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({
        error: 'GEMINI_API_KEY is not configured on the server.',
      });
    }

    const contents = messages.map((m: { role: string; content: string }) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }],
    }));

    let sysInstruction = BRO_SYSTEM_INSTRUCTION;
    if (category) {
      sysInstruction += `\nCurrent focus mode: ${category}. Provide targeted, deeply useful assistance.`;
    }
    if (customPrompt) {
      sysInstruction += `\nUser note: ${customPrompt}`;
    }

    // Set headers for SSE
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders?.();

    const streamResponse = await ai.models.generateContentStream({
      model: 'gemini-3.8-flash',
      contents: contents,
      config: {
        systemInstruction: sysInstruction,
      },
    });

    for await (const chunk of streamResponse) {
      const chunkText = chunk.text;
      if (chunkText) {
        res.write(`data: ${JSON.stringify({ text: chunkText })}\n\n`);
      }
    }

    res.write(`data: [DONE]\n\n`);
    res.end();
  } catch (error: any) {
    console.error('Gemini stream error:', error);
    const errorMessage = error?.message || 'Stream generation failed.';
    if (!res.headersSent) {
      res.status(500).json({ error: errorMessage });
    } else {
      res.write(`data: ${JSON.stringify({ error: errorMessage })}\n\n`);
      res.end();
    }
  }
});

// Mount Vite or static files
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`BRO AI server is running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
